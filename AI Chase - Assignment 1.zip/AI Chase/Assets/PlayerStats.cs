﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStats : MonoBehaviour
{   
    
private float currentHealth;




    // Update is called once per frame
    void Update()
    {
        
    }

}